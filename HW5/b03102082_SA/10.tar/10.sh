#!/usr/bin/env bash

mkdir /repo
echo "[nasa-repo]" >> /etc/pacman.conf
echo "Server = file:///repo" >> /etc/pacman.conf
repo-add /repo/nasa-repo.db.tar.gz *.pkg.tar.xz
cp *.pkg.tar.xz /repo
pacman-key --init
pacman-key --add public_key
gpg --import public_key
pacman-key --lsign-key 75E8133E2D489C7F5A8550C3358BDDED3D816A71

